#include <ros/ros.h>
#include <actionlib/server/simple_action_server.h>  // 这是一个library里面一个做好的包（simple_action_server）里面的头文件
#include "dodishes/DoDishesAction.h"  // 这个头文件是重点，在上一部分生成的action消息的头文件

// 为服务端数据类型定义别名
typedef actionlib::SimpleActionServer<dodishes::DoDishesAction> Server;

// 收到action的goal后调用该回调函数
void execute(const dodishes::DoDishesGoalConstPtr & goal, Server * as)
{
    ros::Rate r(1);
    dodishes::DoDishesFeedback feedback;

    ROS_INFO("Dishwasher %d is working.", goal->dishwasher_id);

    // 假设洗盘子的进度，并且按照1hz的频率发布进度feedback
    for (int i = 1; i <= 10; i++)
    {
        feedback.percent_complete = i * 10;

	// 发布feedback
        as->publishFeedback(feedback);

        r.sleep();
    }

    // 当action完成后，向客户端返回结果
    ROS_INFO("Dishwasher %d finish working.", goal->dishwasher_id);
    as->setSucceeded();
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "do_dishes_server");
    ros::NodeHandle n;

    // 定义一个服务器
    Server server(n, "do_dishes", boost::bind(&execute, _1, &server), false);
    // 其中的参数n，就是NodeHandle。而“do_dishes”，是你给server起的名字
    // boost::bind(&execute, _1, &server)是当收到新的goal时候需要的返回函数
    // false的意思是暂时不启动这个server
    
    server.start();  // 服务器开始运行

    ros::spin();

    return 0;
}

