#pragma once

#include <ros/ros.h>
#include "sensor_msgs/LaserScan.h"
#include "sensor_msgs/PointCloud2.h"
#include "geometry_msgs/Twist.h"

namespace smb_highlevel_controller
{

class SmbHighlevelController
{
 public:
    SmbHighlevelController(ros::NodeHandle & nodeHandle);
    virtual ~SmbHighlevelController();

 private:
    bool readParameters();
    void scanCallback(const sensor_msgs::LaserScan::ConstPtr & scan_msg);
    //void pclCallback(const sensor_msgs::PointCloud2::ConstPtr & pcl_msg);
    ros::NodeHandle & nodeHandle_;
    ros::Subscriber scan_subscriber_;
    //ros::Subscriber pcl_subscriber_;
    ros::Publisher p_controller_publisher_;
    std::string topic_;
    int queue_size_;
    float x_pillar_;
    float y_pillar_;
    float alpha_pillar_;
    geometry_msgs::Twist p_controller_;

};

}
