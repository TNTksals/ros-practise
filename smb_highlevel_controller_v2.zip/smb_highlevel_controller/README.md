ROS课程 2021

第三次课后作业

理论

1. TF Transformation System

2. rqt User Interface

3. Robot models (URDF)

4. Simulation descriptions (SDF)

练习

本次练习的目标是实现SMB机器人的闭环控制。你会从机器人的激光扫描中提取出圆柱体的位置然后操控机器人执行一些动作，比如说朝向圆柱体运动。

1. 在课程的web中，下载**smb_common_v2**压缩文件。解压缩到*~/git*文件夹中。然后将其复制到*/Workspace/smb_ws/src*文件。使用catkin编译这个smb包
2. 修改上一次的launch文件使其能够满足：
   - 键盘操控的节点被移除
   - **$(find smb_highlevel_controller)/worlds/singlePillar.world**被加载进去世界。你可以从web中找到**singlePillar.world**这个文件，然后将其移动到文件夹中
2. 从激光扫描中提取圆柱体**相对**于机器人的**位置**
4. 创建一个**发布者**在话题***/cmd_vel***以实现通过发布**twist消息**控制SMB机器人的目的。你需要在*CMakeLists.txt*和*package.xml*中添加**geometry_msgs**这个依赖。
5. 写一个简单的P控制器**操控SMB朝向圆柱体运动**。记得使用ROS参数服务器调整你的控制器参数！在**激光扫描的话题的回调函数**中实现这个代码。为了确保圆柱体能很好的在激光扫描中可视化，设置***laser_scan_min_height***为-0.2，并设置***laser_scan_max_height***为1.0。你可以将他们设置为**参数**然后传给*smb_gazebo.launch*
6. 在RViz中添加机器人模型插件以可视化SMB机器人
7. 在RViz中添加**tf**坐标系显示

评估标准

1. 启动launch文件，SMB应该能够驶向圆柱体
   - SMB能移动   （20%）
   - SMB撞击到圆柱体 （30%）
2. 检查RViz的设置（TF，RobotModel还有激光扫描）
   - TF  （6%）
   - RobotModel    （7%）
   - 激光扫描 （7%）
3. 可视化标记正确的在RViz中显示出来
   - 标记坐标系的位置是正确的 （15%）
   - 标记可视化靠近圆柱体（意味着所有的可视化参数是正确的） （15%）

请注意，所有功能都必须在**类**内部实现，而不是在实例化类的 main() 函数中实现。 如果您不遵守此规则，您将失去 20% 的积分。



