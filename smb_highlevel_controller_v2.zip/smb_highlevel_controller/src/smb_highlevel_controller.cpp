#include "smb_highlevel_controller/smb_highlevel_controller.h"
#include <string>
#include <cmath>

namespace smb_highlevel_controller
{
    SmbHighlevelController::SmbHighlevelController(ros::NodeHandle & nodeHandle)
            : nodeHandle_(nodeHandle)
    {
        if (!readParameters())
        {
            ROS_ERROR("Could not read parameters.");
            ros::requestShutdown();
        }
        scan_subscriber_ = nodeHandle_.subscribe("/scan", 1000, &SmbHighlevelController::scanCallback, this);
        //pcl_subscriber_ = nodeHandle_.subscribe("/rslidar_points", 1000, &SmbHighlevelController::pclCallback, this);
        p_controller_publisher_ = nodeHandle_.advertise<geometry_msgs::Twist>("/cmd_vel", 1000);
        ROS_INFO("Successfully launched node.");
    }

    SmbHighlevelController::~SmbHighlevelController()
    {
    }

    bool SmbHighlevelController::readParameters()
    {
        bool success = true;
        success &= nodeHandle_.getParam("/smb_highlevel_controller/topic", topic_);
        success &= nodeHandle_.getParam("/smb_highlevel_controller/queue_size", queue_size_);
        return success;
    }

    /*
    void SmbHighlevelController::pclCallback(const sensor_msgs::PointCloud2::ConstPtr & pcl_msg)
    {
        ROS_INFO_STREAM("size of points: " << pcl_msg->data.size());
    }
    */

    void SmbHighlevelController::scanCallback(const sensor_msgs::LaserScan::ConstPtr & scan_msg)
    {
        int size = scan_msg->ranges.size();
        float min = scan_msg->ranges[0];
        float count = 0;
        for (int i = 0; i < size; i++)
        {
            if (min > scan_msg->ranges[i])
            {
                min = scan_msg->ranges[i];
                count = i;
            }
        }
        alpha_pillar_ = scan_msg->angle_min + count * scan_msg->angle_increment;
        //ROS_INFO_STREAM("minimum distance: " << min);
        x_pillar_ = min * cos(alpha_pillar_);
        y_pillar_ = min * sin(alpha_pillar_);
        ROS_INFO_STREAM("Pillar offset angle(rad): " << alpha_pillar_);
        ROS_INFO_STREAM("pillar x distance(m): " << x_pillar_);
        ROS_INFO_STREAM("pillar y distance(m): " << y_pillar_);

        ros::Rate loop_rate(10);
        while (ros::ok())
        {
            /*
            // Another method to drive the SMB robot into the pillar
            float p_gain_vel = 0.1;
            float p_gain_ang = 0.4;
            if(x_pillar_ > 0.2)
            {
                if (x_pillar_ <= 0.4 )
                {
                    p_controller_.linear.x = 0;
                    p_controller_.angular.z = 0;
                }
                else
                {
                    p_controller_.linear.x = x_pillar_ * p_gain_vel;
                    p_controller_.angular.z = y_pillar_ * p_gain_ang;
                }
            }
            else
            {
                p_controller_.linear.x = 0;
                p_controller_.angular.z = 0;
            }
            */
            float x_vel = 0.3;
            float p_gain = 0.5;
            p_controller_.linear.x = x_vel;
            p_controller_.angular.z = alpha_pillar_ * p_gain;
            p_controller_publisher_.publish(p_controller_);
            ros::spinOnce();
        }
    }
}
