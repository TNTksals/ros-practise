#include "ros/ros.h" // 导入ROS系统包含核心公共头文件
#include "std_msgs/String.h" // 导入std_msgs/String消息头文件，这个是由std_msgs包的string.msg文件自动生成

// 接收到chatter话题的消息后，回调函数就会被调用并且收到的消息会作为参数
void chatterCallback(const std_msgs::String::ConstPtr& msg)
{
  ROS_INFO("I heard: [%s]", msg->data.c_str()); // 将接收到的消息打印出来
}

int main(int argc, char **argv)
{

  ros::init(argc, argv, "listener"); // 初始化ROS节点

  ros::NodeHandle n; // 创建节点句柄


  ros::Subscriber sub = n.subscribe("chatter", 1000, chatterCallback);
  // 创建一个Subscriber，订阅名为chatter的topic，指定回调函数chatterCallback


  ros::spin(); // 启动自循环，等待回调函数

  return 0;
}
