#include "ros/ros.h" // 导入ROS系统包含核心公共文件
#include "std_msgs/String.h" // 导入std_msgs/String消息头文件，这个由std_msgs包的string.msg自动生成

#include <sstream>

int main(int argc, char **argv)
{

  ros::init(argc, argv, "talker"); // ROS节点初始化，指定节点名称为"talker"，节点名称要保持唯一性


  ros::NodeHandle n; // 创建节点句柄


  ros::Publisher chatter_pub = n.advertise<std_msgs::String>("chatter", 1000);
  // 创建一个Publisher，发布名为chatter的topic，消息类型为std_msgs::String，队列长度10 

  ros::Rate loop_rate(10); // 指定发布消息的频率

  int count = 0;
  while (ros::ok()) // 检查节点是否应继续运行，当接收到SIGINT(Ctrl+C)或者 ros::shutdown() 被调用时返回false
  {

    std_msgs::String msg; // 初始化std_msgs::String msg类型的消息

    std::stringstream ss; // 初始化std::stringstream类型的消息
    ss << "hello world " << count; // 定义字符串流"hello world"并赋给ss
    msg.data = ss.str(); // 最后转换为字符串赋值给 msg.data

    ROS_INFO("%s", msg.data.c_str()); // 输出调试信息


    chatter_pub.publish(msg); // 发布消息

    ros::spinOnce(); // 处理传入消息的回调函, 不是必需要的，但是保持增加这个调用，是好习惯

    loop_rate.sleep(); // 按照循环频率延时
    ++count;
  }


  return 0;
}
