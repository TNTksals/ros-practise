#include <ros/ros.h>
#include "finaltest/AddTwoInts.h"

 // service 回调函数，输入参数req，输出参数res
bool add(finaltest::AddTwoInts::Request & req, finaltest::AddTwoInts::Response & res)
{
    res.sum = req.a + req.b;
    ROS_INFO("request: x=%ld, y=%ld", long (req.a), long (req.b));   // 显示请求数据
    ROS_INFO("sending back response: [%ld]", long (res.sum));   // 设置反馈数据
    return true;
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "add_two_ints_server");  // ROS节点初始化
  ros::NodeHandle n("~");  // 创建节点句柄

  // 创建一个名为 add_two_ints 的 server，注册回调函数 add
  ros::ServiceServer service = n.advertiseService("add_two_ints", add);
  ROS_INFO("Ready to add two ints.");
  ros::spin();  // 循环等待回调函数

  return 0;
}
