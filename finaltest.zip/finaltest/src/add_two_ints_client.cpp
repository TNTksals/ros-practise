#include <ros/ros.h>
#include "finaltest/AddTwoInts.h"
#include <cstdlib>

int main(int argc, char **argv)
{
  ros::init(argc, argv, "add_two_ints_client");  // 初始化ROS节点
  if (argc != 3)
  {
    ROS_INFO("usage: add_two_ints_client X Y");
    return 1;
  }

  ros::NodeHandle n("~");  // 创建节点句柄

  // 为 add_two_ints 服务创建一个客户端，连接名为 add_two_ints 的 service
  ros::ServiceClient client = n.serviceClient<finaltest::AddTwoInts>("add_two_ints");

  // 初始化 finaltest::AddTwoInts 的请求数据
  finaltest::AddTwoInts srv;
  srv.request.a = atoll(argv[1]);
  srv.request.b = atoll(argv[2]);
  if (client.call(srv))  // 请求服务调用
  {
    ROS_INFO("Sum: %ld", long (srv.response.sum));
  }
  else
  {
    ROS_ERROR("Failed to call service add_two_ints");
    return 1;
  }

  return 0;
}
