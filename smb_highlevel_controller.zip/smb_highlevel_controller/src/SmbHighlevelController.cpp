#include "smb_highlevel_controller/SmbHighlevelController.h"
#include <string>
namespace smb_highlevel_controller
{
    SmbHighlevelController::SmbHighlevelController(ros::NodeHandle& nodeHandle) : nodeHandle_(nodeHandle)
    {
        if (!readParameters())
        {
            ROS_ERROR("Could not read parameters.");
            ros::requestShutdown();
        }
        scan_subscriber_ = nodeHandle_.subscribe("/scan", 1000, &SmbHighlevelController::scanCallback, this);
        pcl_subscriber_ = nodeHandle_.subscribe("/rslidar_points", 1000, &SmbHighlevelController::printCallback, this);
        ROS_INFO("Successfully launched node.");
    }

    SmbHighlevelController::~SmbHighlevelController()
    {
    }

    bool SmbHighlevelController::readParameters()
    {
        bool success = true;
        success &= nodeHandle_.getParam("/smb_highlevel_controller/topic", topic_);
        success &= nodeHandle_.getParam("/smb_highlevel_controller/queue_size", queue_size_);
        return success;
    }

    void SmbHighlevelController::printCallback(const sensor_msgs::PointCloud2::ConstPtr & msg)
    {
        ROS_INFO_STREAM("size of points: " << msg->data.size());
    }

    void SmbHighlevelController::scanCallback(const sensor_msgs::LaserScan & msg)
    {
        std::vector<float> ranges = msg.ranges;
        int i = 0;
        int j = 0;
        float t = 0;
        for (i = 0; i < (ranges.size()-1); i++)
        {
            for (j = 0; j < (ranges.size()-i); j++)
            {
                if (ranges[j] < ranges[j+1])
                {
                    t = ranges[j];
                    ranges[j] = ranges[j+1];
                    ranges[j+1] = t;
                }
            }
        }
        ROS_INFO_STREAM("minimum distance " << ranges[i]);
    }
}
