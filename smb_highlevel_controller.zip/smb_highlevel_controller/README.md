### 课程 2

课程结构

- ROS 软件包结构
- 使用 CLion 开发 ROS 程序
- ROS C++ 客户端库
- ROS *subscribers* and *publishers*
- ROS 参数服务器
- RViz 可视化

作业

在这个练习中，你将创建你的第一个 ROS 包。这个包应该能够**订阅来自 SMB 机器人的 */laser_scan* 的信息并处理传入的数据**。这个节点将是接下来作业的基础。使用 CLion 来编辑你的包（第2讲幻灯片 7）。

请务必看一下 ROS 模板，以供参考。

<https://github.com/leggedrobotics/ros_best_practices>. 它将对你的作业有很大帮助，因为它有一个节点与你在这个作业中要写的很相似

1. 创建软件包 *smb_highlevel_controller*。你可以使用 *catkin create pkg* 命令来创建一个新的包，并添加依赖 *roscpp* 和 *sensor_msgs*。

1. 查看 *CMakelists.txt* 和 *package.xml* 文件。(第2讲幻灯片4-6) 

1. 为 ***/scan* 话题**创建一个**订阅者**。(第2讲幻灯片13)

1. 为话题 */scan* 的 *suscriber* 添加一个**参数文件（*yaml*）**，其中的参数包括**主题名称（*topic*）**和**消息队列（*queue_size***）大小。(第2讲幻灯片 16)

1. 为  */scan* 话题的订阅者创建一个回调函数，从 *sensor_msg* 的测量数据中 **(*float32[] ranges*) 输出最小的距离测量值**给终端 (使用*logging*)。在下面的网址可以查看消息的类型 

   <http://docs.ros.org/en/api/sensor_msgs/html/msg/LaserScan.html>

1. 将你在练习1中的自己写的启动文件添加到这个包中，并将其修改为能够：

   + 运行 *smb\_highlevel\_controller* 节点.
   + 加载参数文件进参数服务器.
8. 在本作业你要编写的 *launch* 文件中 include *smb\_gazebo.launch* 文件，并**将 laser_enable 的值value设置为 *true***。
8. 在 *RViz* 中显示 */LaserScan* ，并**将  *RViz* 加入你的 *launch* 文件**中。确保**将 *Fixed Frame*设置为 *odom*** ，并改变激光扫描点（size）的大小。然后按 ctrl+s 保存你当前的RViz配置为**默认配置**。(第2讲 幻灯片18-20) 

10. [OPTIONAL] 查看 *pointcloud\_to\_laserscan* （在 *smb_gazebo* 的启动文件）节点，找出它在做什么。它发布哪个主题上，又订阅了哪个主题？在 Rviz 中可视化查看 *3D point cloud* 和 *laser scan*。
10. [OPTIONAL] 创建一个节点**订阅 *3D pointcloud*** 并且打印出 ***points* 的数量 (*size*)**

<img src="https://i.loli.net/2021/11/11/AQ8CBaKbLzJqGRu.jpg" alt="Aspose.Words.37f2a14a-9652-44bf-be4d-15fe44fa253c.002.jpeg" style="zoom:200%;" />

评分标准

- 成功启动控制器节点。在终端中有激光扫描仪（*/laser_scan*）的**数据变化**输出。[40%]
- 检查节点是否按照**模板的建议**执行. [30%]
- 有用到参数文件 [15%]
- */laser scan*  在 *RViz* 中的可视化的情况是否如图所示? [15%]

OPTIONAL（附加部分评分标准）

- 正确解释 ***pointcloud\_to\_laserscan* 节点**在做什么， *3D pointcloud* 的数据是否随着机器人的移动而变化? [10% ]

- *3D pointcloud* 中的点的数量是否显示在终端？回调的实现是否正确? [10% ]

  ![Aspose.Words.37f2a14a-9652-44bf-be4d-15fe44fa253c.003.png](https://i.loli.net/2021/11/11/ctJ7q68jRb4QGZu.png)![Aspose.Words.37f2a14a-9652-44bf-be4d-15fe44fa253c.004.png](https://i.loli.net/2021/11/11/kXxuCBYsQIVJZaM.png)
