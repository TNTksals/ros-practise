#ifndef SMBHIGHLEVELCONTROLLER_H
#define SMBHIGHLEVELCONTROLLER_H

#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <sensor_msgs/PointCloud2.h>

namespace smb_highlevel_controller
{
class SmbHighlevelController
{
public:
    SmbHighlevelController(ros::NodeHandle& nodeHandle);
    virtual ~SmbHighlevelController();

private:
    bool readParameters();
    void scanCallback(const sensor_msgs::LaserScan & msg);
    void printCallback(const sensor_msgs::PointCloud2::ConstPtr & msg);

    ros::NodeHandle& nodeHandle_;
    ros::Subscriber scan_subscriber_;
    ros::Subscriber pcl_subscriber_;
    std::string topic_;
    int queue_size_;
};
}

#endif