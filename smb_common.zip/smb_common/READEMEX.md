#  第一课作业

## 作业

1、

从此链接https://ethz.ch/content/dam/ethz/special-interest/mavt/robotics-n-intelligent-systems/rsl-dam/ROS2021/lec1/smb_common.zip下载smb_common压缩包，解压并放在你的工作空间src文件夹内，使用catkin build编译。学会看报错信息，自行安装依赖。

2、

用roslaunch启动仿真，用以下命令查看node和topic

rosnode list
rostopic list
rostopic echo [TOPIC]
rostopic hz [TOPIC]
rqt_graph

你可以从以下网站获取相关信息：

http://wiki.ros.org/rostopic
http://wiki.ros.org/rosnode

3、

在终端给仿真的机器人发速度指令（rostopic pub [TOPIC]）

4、

使用**teleop_twist_keyboard**包来用键盘控制仿真的机器人。从网上（github）下载并编译它的源码。

5、

写一个launch文件，include smb_gazebo.launch文件，并修改world_file这个参数，修改为/usr/share/gazebo-11/worlds目录下的任意一个world。（例如worlds/robocup14_spl_field.world）。第一次加载会多花点时间。

## 评分标准

- 检查teleop_twist_keyboard是否是从源码编译的。（使用roscd teleop_twist_keyboard应该跳转到你的工作空间内）（40分）

- 启动launch文件。用键盘控制机器人所需要的所有模块都应被启动。（60分）

  (第一项可截一张图，内容是使用roscd teleop_twist_keyboard后终端跳转到了你的工作空间内。第二项可截一下你写的launch文件)

## 提示

- 如果发布速度指令机器人动一下就停了，请定义发布者发布的频率。在终端输入rostopic pub -h可获取相关帮助。