# README #

[![Build Status](https://ci.leggedrobotics.com/buildStatus/icon?job=bitbucket_leggedrobotics/smb_common/master)](https://ci.leggedrobotics.com/job/bitbucket_leggedrobotics/job/smb_common/job/master/)

Common packages for the Super Mega Bot robot.  

TROUBLESHOOTING  

Exceptions thrown: `export IGN_IP=127.0.0.1`  
Try:  `export IGN_IP=127.0.0.1`  
